import React from 'react';

// Core SVGs
export const SearchIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="10" cy="10" r="6"></circle>
    <line x1="21" y1="21" x2="14.5" y2="14.5"></line>
  </svg>
);

export const BrainCircuitIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ transform: 'scale(1.3)' }}>
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/>
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>
    <path d="M15 13a4.5 4.5 0 0 1-3-4"/>
    <path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/>
    <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/>
    <path d="M3.477 10.896a4 4 0 0 1 .585-.396"/>
    <path d="M19.938 10.5a4 4 0 0 1 .585.396"/>
    <path d="M6 18a4 4 0 0 1-1.967-.516"/>
    <path d="M19.967 17.484A4 4 0 0 1 18 18"/>
  </svg>
);

export const ScaleIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3v18" />
    <path d="M9 21h6" />
    <path d="M4 7h16" />
    <path d="M4 7l-2 8h4l-2-8z" />
    <path d="M2 15s1 2 2 2 2-2 2-2" />
    <path d="M20 7l-2 8h4l-2-8z" />
    <path d="M18 15s1 2 2 2 2-2 2-2" />
    <circle cx="12" cy="7" r="1" fill="currentColor" />
  </svg>
);

export const RocketIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path>
    <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path>
    <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"></path>
    <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path>
  </svg>
);

export const NetworkIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3" />
    <rect x="4" y="4" width="4" height="4" rx="1" />
    <path d="M7.5 7.5L10 10" />
    <rect x="16" y="4" width="4" height="4" rx="1" />
    <path d="M16.5 7.5L14 10" />
    <rect x="4" y="16" width="4" height="4" rx="1" />
    <path d="M7.5 16.5L10 14" />
    <rect x="16" y="16" width="4" height="4" rx="1" />
    <path d="M16.5 16.5L14 14" />
    <circle cx="3" cy="12" r="1.5" />
    <path d="M4.5 12h4.5" />
    <circle cx="21" cy="12" r="1.5" />
    <path d="M19.5 12h-4.5" />
  </svg>
);

export const ClipboardIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
    <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
    <path d="M9 14l2 2 4-4"></path>
  </svg>
);

export const SectionChartIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
    <path d="M3 2v20h20v-2H5V2H3z" />
    <rect x="7" y="14" width="3" height="6" />
    <rect x="12" y="10" width="3" height="10" />
    <rect x="17" y="6" width="3" height="14" />
  </svg>
);

export const DatabaseIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
    <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path>
    <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
    <path d="M12 12v-7"></path>
    <path d="m9 8 3-3 3 3"></path>
  </svg>
);

export const SectionDatabaseIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
    <path d="M3 5v4c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
    <path d="M3 9v4c0 1.66 4 3 9 3s9-1.34 9-3V9"></path>
    <path d="M3 13v4c0 1.66 4 3 9 3s9-1.34 9-3v-4"></path>
  </svg>
);

// Official Tool SVG Components
export const TableauIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <path d="M12 9v6M9 12h6" stroke="#1C4B82" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M6 6h4M8 4v4" stroke="#E8762D" strokeWidth="2" strokeLinecap="round" />
    <path d="M14 6h4M16 4v4" stroke="#5B879B" strokeWidth="2" strokeLinecap="round" />
    <path d="M6 16h4M8 14v4" stroke="#21A366" strokeWidth="2" strokeLinecap="round" />
    <path d="M14 16h4M16 14v4" stroke="#1C4B82" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const ThoughtSpotIcon = () => (
  <svg viewBox="0 0 100 100" fill="none" style={{width: '100%', height: '100%'}}>
    {/* 3 horizontal bars */}
    <rect x="10" y="10" width="80" height="12" fill="currentColor"/>
    <rect x="10" y="28" width="80" height="12" fill="currentColor"/>
    <rect x="10" y="46" width="80" height="12" fill="currentColor"/>
    {/* 3 vertical bars, centered */}
    <rect x="36" y="46" width="6" height="52" fill="currentColor"/>
    <rect x="47" y="46" width="6" height="52" fill="currentColor"/>
    <rect x="58" y="46" width="6" height="52" fill="currentColor"/>
    {/* dot on bottom right */}
    <circle cx="80" cy="88" r="10" fill="currentColor"/>
  </svg>
);

export const ExcelIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <rect x="2" y="3" width="20" height="18" rx="2" fill="#21A366"/>
    <path d="M7 16L10 12L7 8H9L11 10.5L13 8H15L12 12L15 16H13L11 13.5L9 16H7Z" fill="white"/>
  </svg>
);

export const MicroStrategyIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <circle cx="12" cy="12" r="11" fill="#D9232E"/>
    <rect x="6" y="7" width="3.5" height="10" fill="white"/>
    <rect x="10.5" y="7" width="3.5" height="10" fill="white"/>
    <path d="M15 17h3.5V9.5L15 7v10z" fill="white"/>
  </svg>
);

export const ScalaIcon = () => (
  <svg viewBox="0 0 256 416" fill="none" style={{width: '100%', height: '100%'}}>
    <defs>
      <linearGradient x1="0%" y1="50%" y2="50%" id="a"><stop stopColor="#4F4F4F" offset="0%"/><stop offset="100%"/></linearGradient>
      <linearGradient x1="0%" y1="50%" y2="50%" id="b"><stop stopColor="#C40000" offset="0%"/><stop stopColor="#F00" offset="100%"/></linearGradient>
    </defs>
    <path d="M0 288v-32c0-5.394 116.377-14.428 192.2-32 36.628 8.49 63.8 18.969 63.8 32v32c0 13.024-27.172 23.51-63.8 32C116.376 302.425 0 293.39 0 288" fill="url(#a)" transform="matrix(1 0 0 -1 0 544)"/>
    <path d="M0 160v-32c0-5.394 116.377-14.428 192.2-32 36.628 8.49 63.8 18.969 63.8 32v32c0 13.024-27.172 23.51-63.8 32C116.376 174.425 0 165.39 0 160" fill="url(#a)" transform="matrix(1 0 0 -1 0 288)"/>
    <path d="M0 224v-96c0 8 256 24 256 64v96c0-40-256-56-256-64" fill="url(#b)" transform="matrix(1 0 0 -1 0 416)"/>
    <path d="M0 96V0c0 8 256 24 256 64v96c0-40-256-56-256-64" fill="url(#b)" transform="matrix(1 0 0 -1 0 160)"/>
    <path d="M0 352v-96c0 8 256 24 256 64v96c0-40-256-56-256-64" fill="url(#b)" transform="matrix(1 0 0 -1 0 672)"/>
  </svg>
);

export const AlteryxIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <circle cx="12" cy="12" r="11" fill="#1C84C6"/>
    <text x="12" y="16.5" fontFamily="Arial, Helvetica, sans-serif" fontSize="15" fontWeight="bold" fill="white" textAnchor="middle">a</text>
  </svg>
);

export const MoonIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
  </svg>
);

export const SunIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="5"></circle>
    <line x1="12" y1="1" x2="12" y2="3"></line>
    <line x1="12" y1="21" x2="12" y2="23"></line>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
    <line x1="1" y1="12" x2="3" y2="12"></line>
    <line x1="21" y1="12" x2="23" y2="12"></line>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
  </svg>
);

export const PythonIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9v-2h2v2zm0-4H9V8h2v4zm4 4h-2v-2h2v2zm0-4h-2V8h2v4z" fill="#306998"/>
    <path d="M12 12c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" fill="#FFD43B"/>
  </svg>
);

export const SparkRealIcon = () => (
  <svg viewBox="0 0 414 215" style={{width: '100%', height: '100%'}} xmlns="http://www.w3.org/2000/svg">
    <g transform="matrix(1.33 0 0 1.33 0 0)">
      <path d="m284 81.5c-.269-.575-.39-.864-.535-1.14-3.89-7.4-7.77-14.8-11.7-22.2-.394-.742-.344-1.18.195-1.82 6.19-7.23 12.3-14.5 18.5-21.7.219-.254.414-.523.496-.976-1.8.469-3.6.933-5.41 1.41-7.47 1.98-15 3.95-22.4 5.96-.695.187-1.01-.016-1.36-.594-4.24-7.09-8.51-14.2-12.8-21.2-.219-.367-.458-.723-.926-1.03-.344 1.89-.692 3.77-1.03 5.66-1.19 6.67-2.38 13.3-3.56 20-.129.719-.305 1.44-.367 2.16-.059.688-.414.942-1.04 1.14-8.81 2.77-17.6 5.56-26.4 8.35-.386.121-.765.281-1.18.656 7.2 2.86 14.4 5.72 21.7 8.63-.266.211-.442.375-.637.5-4.5 2.91-9.01 5.82-13.5 8.74-.539.352-.965.402-1.57.129-5.38-2.42-10.8-4.8-16.2-7.2-2.42-1.08-4.59-2.51-6.28-4.59-3.83-4.68-3.07-10 2.03-13.3 1.67-1.07 3.57-1.86 5.46-2.48 8.63-2.81 17.3-5.52 25.9-8.24.726-.231 1.06-.555 1.2-1.34 1.16-6.68 2.35-13.4 3.56-20 .644-3.57.984-7.22 2.72-10.5.665-1.26 1.46-2.49 2.42-3.54 3.44-3.82 8.23-3.96 11.9-.328 1.23 1.23 2.28 2.67 3.19 4.16 4 6.53 7.94 13.1 11.9 19.7.465.777.883.933 1.74.707 9.65-2.59 19.3-5.14 29-7.69 2-.527 4.01-.718 6.06-.335 4.45.832 6.4 4.22 4.89 8.53-.683 1.96-1.87 3.61-3.2 5.18-6.74 7.93-13.5 15.9-20.2 23.8-.551.648-.562 1.11-.18 1.84 4.04 7.61 8.04 15.2 12.1 22.9.961 1.82 1.7 3.72 1.72 5.81.047 4.76-3.44 8.66-8.17 9.36-2.65.387-5.11-.179-7.6-.945-6.05-1.87-12.1-3.71-18.2-5.54-.563-.168-.778-.391-.879-.996-.696-4.27-1.46-8.53-2.2-12.8-.019-.117.016-.242.036-.504 6.91 1.91 13.8 3.79 20.9 5.76" fill="#e25a1c"/>
      <path d="m272 144c-5.46-.008-10.9-.035-16.4-.011-.723 0-1.13-.207-1.53-.821-6.46-9.84-13-19.7-19.4-29.5-.207-.312-.426-.613-.793-1.14-1.39 10.6-2.76 21-4.13 31.4h-14.3c.168-1.39.317-2.74.493-4.08 1.39-10.7 2.8-21.3 4.2-32 1.34-10.2 2.67-20.4 4.03-30.6.039-.301.242-.688.488-.848 4.92-3.21 9.86-6.39 14.8-9.57.071-.047.172-.051.426-.125-1.49 11.4-2.97 22.7-4.46 34 .059.039.117.082.176.121 7.75-8.58 15.5-17.2 23.4-25.9.227 1.32.426 2.45.621 3.58.555 3.23 1.09 6.48 1.68 9.71.121.652-.055 1.05-.488 1.51-5.01 5.24-10 10.5-15 15.8-.219.231-.426.469-.676.743.16.253.297.5.457.726 8.61 12.1 17.2 24.2 25.8 36.3.156.219.382.391.574.586v.191" fill="currentColor"/>
      <path d="m103 112c-.219-1.11-.375-2.75-.871-4.28-2.4-7.39-9.97-11.4-17.8-9.61-8.61 2-14.8 8.77-15.6 17.6-.66 6.5 2.84 12.8 9.34 15.1 5.24 1.89 10.3 1.1 15-1.71 6.21-3.72 9.57-9.25 10-17.1zm-37.8 27.5c-.422 3.18-.828 6.17-1.22 9.17-.523 3.98-1.05 7.97-1.55 12-.058.465-.199.672-.699.668-3.93-.015-7.86-.011-11.8-.019-.09 0-.18-.047-.391-.109.238-1.88.469-3.77.715-5.65.867-6.6 1.73-13.2 2.61-19.8 1.01-7.56 1.8-15.1 3.09-22.6 2.28-13.3 13.6-24.7 26.8-27.6 7.67-1.66 15-.891 21.7 3.43 6.68 4.3 10.5 10.6 11.4 18.4 1.24 11.1-2.85 20.3-10.7 28-5.18 5.01-11.4 8.19-18.5 9.27-7.37 1.11-14.3-.117-20.5-4.46-.227-.16-.473-.3-.863-.546" fill="currentColor"/>
      <path d="m58.6 76.5c-4.4 3.28-8.65 6.44-12.9 9.61-.687-1.08-1.3-2.16-2.02-3.17-1.85-2.59-4.15-4.52-7.49-4.75-2.78-.196-5.16.718-7.05 2.77-1.69 1.83-1.91 4.44-.332 6.51 1.74 2.28 3.64 4.44 5.59 6.55 3.23 3.5 6.6 6.86 9.8 10.4 2.91 3.2 5.24 6.78 5.96 11.2.856 5.2-.183 10.1-2.64 14.7-4.55 8.45-11.7 13.4-21.2 14.9-4.18.675-8.34.543-12.4-.657-5.41-1.59-9.18-5.14-11.6-10.1-.855-1.77-1.51-3.64-2.28-5.54 4.73-2.53 9.34-5 14-7.49.16.387.277.711.426 1.02.797 1.59 1.45 3.28 2.43 4.75 2.93 4.35 7.65 5.67 12.4 3.52 1.23-.555 2.42-1.33 3.43-2.23 3.08-2.74 3.66-6.56 1.38-10-1.31-1.98-2.95-3.76-4.55-5.53-3.82-4.24-7.8-8.35-11.5-12.7-2.57-2.98-4.32-6.44-4.88-10.4-.605-4.36.266-8.46 2.53-12.1 5.63-9.11 13.8-13.8 24.6-13.5 6.17.223 11.1 3.11 14.9 7.91 1.13 1.42 2.19 2.89 3.34 4.43" fill="currentColor"/>
      <path d="m163 125c-.719 5.49-1.4 10.7-2.1 15.9-.039.266-.246.625-.469.727-10.7 4.94-24.7 4.25-33.4-5.69-4.7-5.34-6.67-11.7-6.38-18.7.683-16.3 14.2-30.6 30.4-32.6 9.45-1.16 17.7 1.39 24.1 8.74 4.36 5 6.38 11 6.08 17.6-.195 4.36-.879 8.69-1.42 13-.77 6.14-1.61 12.3-2.42 18.4-.031.214-.074.433-.125.711h-12.7c.168-1.41.324-2.79.504-4.17.922-7.09 1.94-14.2 2.75-21.3.504-4.42.187-8.81-1.84-12.9-2.15-4.35-5.75-6.66-10.5-7.16-9.82-1.04-19.2 5.78-21.2 15.4-1.38 6.38.797 12.5 5.88 15.9 4.95 3.29 10.2 3.3 15.6 1.17 2.74-1.08 5.06-2.8 7.28-5.11" fill="currentColor"/>
      <path d="m217 86.3c-.582 4.42-1.16 8.77-1.74 13.2-2.7 0-5.34-.015-7.98.004-2.14.016-4.09 1.4-4.74 3.4-.25.781-.343 1.62-.453 2.44-1.34 10.2-2.67 20.3-4 30.4-.336 2.56-.66 5.12-.996 7.72h-13.3c.246-1.95.48-3.84.726-5.73.863-6.58 1.73-13.2 2.6-19.7.754-5.69 1.43-11.4 2.32-17.1 1.19-7.6 8.75-14.4 16.4-14.7 3.66-.16 7.33-.027 11.1-.027" fill="currentColor"/>
      <path d="m288 144v-5.6h-.031l-2.2 5.6h-.699l-2.2-5.6h-.035v5.6h-1.1v-6.71h1.71l2 5.1 1.97-5.1h1.7v6.71zm-9.74-5.81v5.81h-1.1v-5.81h-2.1v-.899h5.31v.899h-2.1" fill="currentColor"/>
      <path d="m76.3 67.1h3.29l-.778-4.98zm3.81 3.22h-5.47l-1.74 3.41h-3.88l8.55-16h3.74l2.91 16h-3.59l-.516-3.41" fill="currentColor"/>
      <path d="m99.7 61h-1.95l-.656 3.69h1.95c1.18 0 2.11-.773 2.11-2.23 0-.965-.586-1.46-1.46-1.46zm-4.72-3.22h5.12c2.68 0 4.55 1.6 4.55 4.34 0 3.46-2.44 5.78-5.92 5.78h-2.21l-1.04 5.85h-3.34l2.82-16" fill="currentColor"/>
      <path d="m116 67.1h3.29l-.777-4.98zm3.8 3.22h-5.47l-1.74 3.41h-3.88l8.55-16h3.74l2.91 16h-3.59l-.516-3.41" fill="currentColor"/>
      <path d="m141 73.2c-1.13.516-2.37.824-3.62.824-4.23 0-6.88-3.17-6.88-7.14 0-5.08 4.27-9.35 9.35-9.35 1.27 0 2.42.305 3.36.82l-.469 3.83c-.703-.777-1.84-1.32-3.24-1.32-2.91 0-5.5 2.63-5.5 5.68 0 2.32 1.46 4.14 3.76 4.14 1.41 0 2.77-.543 3.69-1.29l-.445 3.8" fill="currentColor"/>
      <path d="m162 67.3h-6.95l-1.13 6.43h-3.33l2.82-16h3.34l-1.12 6.32h6.95l1.13-6.32h3.34l-2.82 16h-3.34l1.12-6.43" fill="currentColor"/>
      <path d="m174 73.7 2.82-16h8.86l-.563 3.22h-5.52l-.563 3.1h5.07l-.563 3.22h-5.07l-.563 3.22h5.52l-.563 3.22h-8.86" fill="currentColor"/>
    </g>
  </svg>
);
