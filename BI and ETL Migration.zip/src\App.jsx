import React from 'react';
import './index.css';
import AgentCard from './components/AgentCard';

import { 
  SearchIcon, BrainCircuitIcon, ScaleIcon, RocketIcon, 
  NetworkIcon, ClipboardIcon, SectionChartIcon, DatabaseIcon, SectionDatabaseIcon,
  MoonIcon, SunIcon 
} from './components/Icons';
import ArchitectureDiagram from './components/ArchitectureDiagram';
import FlowAnimationScreen from './components/FlowAnimationScreen';

const biDiscoverySubAgents = [
  { id: 'sa-tab-disc', label: 'Tableau Discovery' },
  { id: 'sa-exc-disc', label: 'Excel Discovery', isWip: true }
];

const biIntelligenceSubAgents = [
  { id: 'sa-tab-int', label: 'Tableau Intelligence' },
  { id: 'sa-ts-int', label: 'ThoughtSpot Intelligence' },
  { id: 'sa-ms-int', label: 'MicroStrategy Intelligence', isWip: true },
  { id: 'sa-exc-int', label: 'Excel Intelligence', isWip: true }
];

const biRationalisationSubAgents = [
  { id: 'sa-tab-rat', label: 'Tableau Rationalisation' },
  { id: 'sa-exc-rat', label: 'Excel Rationalisation', isWip: true }
];

const biMigrationSubAgents = [
  { id: 'sa-tab-mig', label: 'Tableau' },
  { id: 'sa-ts-mig', label: 'ThoughtSpot' },
  { id: 'sa-ms-mig', label: 'MicroStrategy', isWip: true },
  { id: 'sa-exc-mig', label: 'Excel', isWip: true }
];

const etlDiscoverySubAgents = [];

const etlIntelligenceSubAgents = [
  { id: 'sa-etl-py-int', label: 'Python Intelligence' },
  { id: 'sa-etl-sc-int', label: 'Scala Intelligence', isWip: true },
  { id: 'sa-etl-spk-int', label: 'Spark SQL/PySpark Intelligence', isWip: true }
];

const etlRationalisationSubAgents = [];

const etlMigrationSubAgents = [
  { id: 'sa-alt-mig', label: 'Alteryx' }
];

// Paste your actual URLs here between the quotes
const URL_MAPPINGS = {
  // BI Modernization Agent URLs
  'sa-tab-disc': '', // Tableau Discovery
  'sa-exc-disc': '', // Excel Discovery
  'sa-tab-int': '',  // Tableau Intelligence
  'sa-ts-int': '',   // ThoughtSpot Intelligence
  'sa-ms-int': '',   // MicroStrategy Intelligence
  'sa-exc-int': '',  // Excel Intelligence
  'sa-tab-rat': '',  // Tableau Rationalisation
  'sa-exc-rat': '',  // Excel Rationalisation
  'sa-tab-mig': '',  // Tableau Migration
  'sa-ts-mig': '',   // ThoughtSpot Migration
  'sa-ms-mig': '',   // MicroStrategy Migration
  'sa-exc-mig': '',  // Excel Migration

  // ETL Modernization Agent URLs
  'sa-etl-py-int': '',  // Python Intelligence
  'sa-etl-sc-int': '',  // Scala Intelligence
  'sa-etl-spk-int': '', // Spark SQL/PySpark Intelligence
  'sa-alt-mig': ''      // Alteryx Migration
};

function App() {
  const [biSelections, setBiSelections] = React.useState({});
  const [etlSelections, setEtlSelections] = React.useState({});
  const [biCardSelections, setBiCardSelections] = React.useState({});
  const [etlCardSelections, setEtlCardSelections] = React.useState({});
  const [isDarkMode, setIsDarkMode] = React.useState(false);
  const [animatingSubAgents, setAnimatingSubAgents] = React.useState(null);
  const [pendingLinks, setPendingLinks] = React.useState([]);

  React.useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark-mode');
    } else {
      document.documentElement.classList.remove('dark-mode');
    }
  }, [isDarkMode]);

  const viewportRef = React.useRef(null);
  const stageRef = React.useRef(null);
  const [pageScale, setPageScale] = React.useState(1);

  React.useLayoutEffect(() => {
    const resizePageToViewport = () => {
      const viewport = viewportRef.current;
      const stage = stageRef.current;
      if (!viewport || !stage) return;

      const viewportWidth = viewport.clientWidth;
      const viewportHeight = viewport.clientHeight;
      const contentWidth = stage.scrollWidth;
      const contentHeight = stage.scrollHeight;

      if (!viewportWidth || !viewportHeight || !contentWidth || !contentHeight) return;

      const nextScale = Math.min(
        1,
        viewportWidth / contentWidth,
        viewportHeight / contentHeight
      );

      setPageScale(nextScale);
    };

    resizePageToViewport();

    const resizeObserver = new ResizeObserver(resizePageToViewport);
    if (viewportRef.current) resizeObserver.observe(viewportRef.current);
    if (stageRef.current) resizeObserver.observe(stageRef.current);

    window.addEventListener('resize', resizePageToViewport);
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', resizePageToViewport);
    };
  }, []);

  const updateBiSelection = (cardId, subAgentId) => {
    setBiSelections(prev => ({
      ...prev,
      [cardId]: subAgentId
    }));
  };

  const updateEtlSelection = (cardId, subAgentId) => {
    setEtlSelections(prev => ({
      ...prev,
      [cardId]: subAgentId
    }));
  };

  const updateBiCardSelection = (cardId, isSelected) => {
    setBiCardSelections(prev => ({ ...prev, [cardId]: isSelected }));
  };

  const updateEtlCardSelection = (cardId, isSelected) => {
    setEtlCardSelections(prev => ({ ...prev, [cardId]: isSelected }));
  };

  const handleBiGetStarted = (e) => {
    e.preventDefault();
    const activeIds = [];
    Object.keys(biSelections).forEach(cardId => {
      if (biCardSelections[cardId] && biSelections[cardId]) {
        activeIds.push(biSelections[cardId]);
      }
    });
    
    if (activeIds.length === 0) {
      alert("Please select at least one Agent card and its corresponding sub-agent option.");
      return;
    }

    const priorityOrder = [
      // Priority 1 - Rationalization
      'sa-tab-rat', 'sa-exc-rat',
      // Priority 2 - Migration
      'sa-tab-mig', 'sa-ts-mig', 'sa-ms-mig', 'sa-exc-mig',
      // Priority 3 - Discovery / Intelligence
      'sa-tab-disc', 'sa-exc-disc', 'sa-tab-int', 'sa-ts-int', 'sa-ms-int', 'sa-exc-int'
    ];

    let prioritizedId = priorityOrder.find(id => activeIds.includes(id)) || activeIds[0];

    const links = [];
    if (URL_MAPPINGS[prioritizedId]) {
      links.push(URL_MAPPINGS[prioritizedId]);
    } else {
      links.push(''); // Push empty to show warning if not configured
    }

    setPendingLinks(links);
    setAnimatingSubAgents([prioritizedId]);
  };

  const handleEtlGetStarted = (e) => {
    e.preventDefault();
    const activeIds = [];
    Object.keys(etlSelections).forEach(cardId => {
      if (etlCardSelections[cardId] && etlSelections[cardId]) {
        activeIds.push(etlSelections[cardId]);
      }
    });
    
    if (activeIds.length === 0) {
      alert("Please select at least one Agent card and its corresponding sub-agent option.");
      return;
    }

    const links = [];
    activeIds.forEach(id => {
      if (URL_MAPPINGS[id]) {
        links.push(URL_MAPPINGS[id]);
      } else {
        links.push('');
      }
    });

    setPendingLinks(links);
    setAnimatingSubAgents(activeIds);
  };

  const handleAnimationComplete = () => {
    pendingLinks.forEach(link => {
      if (link && link.trim() !== '') {
        window.open(link, '_blank');
      } else {
        console.warn('URL not configured for this selection. Please add it to URL_MAPPINGS.');
      }
    });
    setAnimatingSubAgents(null);
    setPendingLinks([]);
  };

  return (
    <>
      {animatingSubAgents && (
        <FlowAnimationScreen 
          activeFlows={animatingSubAgents} 
          onComplete={handleAnimationComplete} 
        />
      )}
      {/* Dark Mode Toggle */}
        <button 
          onClick={() => setIsDarkMode(!isDarkMode)} 
          style={{ position: 'fixed', top: '10px', right: '10px', background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-main)', zIndex: 1000 }}
        >
        {isDarkMode ? <SunIcon /> : <MoonIcon />}
      </button>

      <div className="fit-viewport" ref={viewportRef}>
        <div 
          className="fit-stage" 
          ref={stageRef} 
          style={{ transform: `scale(${pageScale})` }}
        >
      <div className="container" style={{position: 'relative'}}>
        {/* Header Section */}
        <div className="header-section">
        <div className="header-content">
          <h1 className="header-title">
            EXL BI And ETL Modernization Suite - <span style={{ fontWeight: 600, opacity: 0.9, letterSpacing: '0.02em' }}>AI on BI</span>
          </h1>
          <p className="header-subtitle">
            Transform your BI and ETL ecosystems with a suite of AI-powered agents.
          </p>
          <p className="header-instruction">
            Select the agents you want to run and get started.
          </p>
        </div>
        
        {/* Right Graphic */}
        <ArchitectureDiagram />
      </div>

      {/* BI Modernization Suite Section */}
      <div className="suite-section">
        <div className="section-header">
          <div className="section-title-wrap">
            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
              <div className="section-header-icon" style={{color: 'var(--orange-main)'}}><SectionChartIcon /></div>
              <h2 className="section-title bi" style={{margin: 0, color: 'var(--orange-main)'}}>BI MODERNIZATION AGENTS</h2>
            </div>
            <p style={{marginLeft: '28px', marginTop: '4px'}}>Transform your BI ecosystem with intelligent agents.</p>
          </div>
        </div>
        
        <div className="card-grid">
          <AgentCard 
            theme="orange"
            iconSvg={<SearchIcon />}
            title="1. BI DISCOVERY AGENT"
            subtitle="Find & Catalog Every Asset"
            subAgents={biDiscoverySubAgents}
            onSelectionChange={(isSelected) => updateBiCardSelection('bi1', isSelected)}
            onSubAgentChange={(id) => updateBiSelection('bi1', id)}
          />
          <AgentCard 
            theme="orange"
            iconSvg={<BrainCircuitIcon />}
            title="2. BI INTELLIGENCE AGENT"
            subtitle="Understand Every Dashboard"
            subAgents={biIntelligenceSubAgents}
            onSelectionChange={(isSelected) => updateBiCardSelection('bi2', isSelected)}
            onSubAgentChange={(id) => updateBiSelection('bi2', id)}
          />
          <AgentCard 
            theme="orange"
            iconSvg={<ScaleIcon />}
            title="3. BI RATIONALISATION AGENT"
            subtitle="Decide What to Keep"
            subAgents={biRationalisationSubAgents}
            onSelectionChange={(isSelected) => updateBiCardSelection('bi3', isSelected)}
            onSubAgentChange={(id) => updateBiSelection('bi3', id)}
          />
          <AgentCard 
            theme="orange"
            iconSvg={<RocketIcon />}
            title="4. BI MIGRATION AGENT"
            subtitle="Convert to Target Platform"
            subAgents={biMigrationSubAgents}
            onSelectionChange={(isSelected) => updateBiCardSelection('bi4', isSelected)}
            onSubAgentChange={(id) => updateBiSelection('bi4', id)}
            showMigrationConfig={true}
          />
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '16px' }}>
          <a href="#" className="btn-primary dark-blue section-action" onClick={handleBiGetStarted}>
            Get Started &rarr;
          </a>
        </div>
      </div>

      {/* ETL Modernization Suite Section */}
      <div className="suite-section" style={{marginTop: '16px'}}>
        <div className="section-header">
          <div className="section-title-wrap">
            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
              <div className="section-header-icon" style={{color: 'var(--blue-btn)'}}><SectionDatabaseIcon /></div>
              <h2 className="section-title etl" style={{margin: 0, color: 'var(--blue-btn)'}}>ETL MODERNIZATION AGENTS</h2>
            </div>
            <p style={{marginLeft: '28px', marginTop: '4px'}}>Modernize your ETL landscape with intelligent agents.</p>
          </div>
        </div>
        
        <div className="card-grid">
          <AgentCard 
            theme="blue"
            iconSvg={<SearchIcon />}
            title="1. ETL DISCOVERY AGENT"
            subtitle="Discover & Inventory ETL Assets"
            subAgents={etlDiscoverySubAgents}
            onSelectionChange={(isSelected) => updateEtlCardSelection('etl1', isSelected)}
            onSubAgentChange={(id) => updateEtlSelection('etl1', id)}
          />
          <AgentCard 
            theme="blue"
            iconSvg={<NetworkIcon />}
            title="2. ETL INTELLIGENCE AGENT"
            subtitle="Extract Lineage & Understand"
            subAgents={etlIntelligenceSubAgents}
            onSelectionChange={(isSelected) => updateEtlCardSelection('etl2', isSelected)}
            onSubAgentChange={(id) => updateEtlSelection('etl2', id)}
          />
          <AgentCard 
            theme="blue"
            iconSvg={<ClipboardIcon />}
            title="3. ETL RATIONALISATION AGENT"
            subtitle="Analyze, Assess & Recommend"
            subAgents={etlRationalisationSubAgents}
            onSelectionChange={(isSelected) => updateEtlCardSelection('etl3', isSelected)}
            onSubAgentChange={(id) => updateEtlSelection('etl3', id)}
          />
          <AgentCard 
            theme="blue"
            iconSvg={<DatabaseIcon />}
            title="4. ETL MIGRATION AGENT"
            subtitle="Migrate & Validate with Confidence"
            subAgents={etlMigrationSubAgents}
            onSelectionChange={(isSelected) => updateEtlCardSelection('etl4', isSelected)}
            onSubAgentChange={(id) => updateEtlSelection('etl4', id)}
            showMigrationConfig={true}
            migrationTarget="Python (Default)"
          />
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '16px' }}>
          <a href="#" className="btn-primary dark-blue section-action" onClick={handleEtlGetStarted}>
            Get Started &rarr;
          </a>
        </div>
      </div>
    </div>
        </div>
      </div>
    </>
  );
}

export default App;
