import React, { useState } from 'react';

const AgentCard = ({ 
  theme, // 'purple', 'blue', 'green', 'orange'
  title, 
  subtitle, 
  iconSvg,
  subAgents = [], // Array of { id, label }
  onSelectionChange,
  onSubAgentChange,
  showMigrationConfig,
  migrationTarget = "Power BI (Default)"
}) => {
  const [selected, setSelected] = useState(false);
  const [selectedSubAgent, setSelectedSubAgent] = useState(null);

  const handleSelect = () => {
    const newVal = !selected;
    setSelected(newVal);
    if (onSelectionChange) onSelectionChange(newVal);
  };

  const handleSubAgentSelect = (id) => {
    const newId = selectedSubAgent === id ? null : id;
    setSelectedSubAgent(newId);
    if (onSubAgentChange) onSubAgentChange(newId);
  };

  const themeClass = `theme-${theme}`;

  return (
    <div className={`agent-card ${theme} ${selected ? 'selected' : ''}`}>
      {/* Header Row: Checkbox + Icon + Titles */}
      <div className="card-header-row">
        <button 
          className={`card-checkbox ${selected ? 'checked' : ''}`} 
          onClick={handleSelect}
          aria-label={`Select ${title}`}
        >
          {selected && (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
          )}
        </button>
        <div className={`card-icon ${theme}`}>
          {iconSvg}
        </div>
        <div className="card-title-stack">
          <h3 className={`card-title ${theme}`}>{title}</h3>
          <h4 className="card-subtitle">{subtitle}</h4>
        </div>
      </div>

      {/* Sub Agents Section */}
      {subAgents.length > 0 && (
        <div className="sub-agents-section">
          <h5 className="sub-agents-title">Sub Agents (Select any one)</h5>
          
          {showMigrationConfig ? (
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '6px' }}>
              <div style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
                <span style={{ fontSize: '12.5px', fontWeight: 'bold', color: 'var(--text-muted)', marginBottom: '8px' }}>From</span>
                {subAgents.map((sa) => (
                  <div key={sa.id} className="sub-agent-item" style={{ marginBottom: '5px' }}>
                    <label className={`sub-agent-radio-label ${sa.isWip ? 'wip' : ''}`} onClick={() => handleSubAgentSelect(sa.id)}>
                      <span className={`sub-agent-radio ${themeClass} ${selectedSubAgent === sa.id ? 'selected' : ''}`} />
                      {sa.label}
                      {sa.isWip && <span className="wip-legend">WIP</span>}
                    </label>
                  </div>
                ))}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', flex: 1, paddingLeft: '16px' }}>
                <span style={{ fontSize: '12.5px', fontWeight: 'bold', color: 'var(--text-muted)', marginBottom: '8px' }}>To</span>
                <div className="sub-agent-item" style={{ marginBottom: '5px' }}>
                  <label className="sub-agent-radio-label" style={{ cursor: 'default' }}>
                    <span className={`sub-agent-radio ${themeClass} ${selectedSubAgent ? 'selected' : ''}`} />
                    {migrationTarget}
                  </label>
                </div>
              </div>
            </div>
          ) : (
            <>
              {subAgents.map((sa) => (
                <div key={sa.id} className="sub-agent-item">
                  <label className={`sub-agent-radio-label ${sa.isWip ? 'wip' : ''}`} onClick={() => handleSubAgentSelect(sa.id)}>
                    <span className={`sub-agent-radio ${themeClass} ${selectedSubAgent === sa.id ? 'selected' : ''}`} />
                    {sa.label}
                    {sa.isWip && <span className="wip-legend">WIP</span>}
                  </label>
                </div>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default AgentCard;

