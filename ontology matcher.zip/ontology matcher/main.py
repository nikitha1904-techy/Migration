import json, os, time
import pandas as pd
from google import genai
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from dotenv import load_dotenv

# ─── CONFIG ───────────────────────────────────────────────────────────────────
load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")   # set via env or paste here
GEMINI_MODEL   = "gemini-2.0-flash"

INPUT_DIR   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "input")
OUTPUT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ontology_mapping_output.xlsx")

# ─── STYLES ───────────────────────────────────────────────────────────────────
GREEN_FILL  = PatternFill("solid", fgColor="C6EFCE")
YELLOW_FILL = PatternFill("solid", fgColor="FFEB9C")
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(bold=True, color="FFFFFF", name="Arial", size=10)
BODY_FONT   = Font(name="Arial", size=9)
BOLD_FONT   = Font(bold=True, name="Arial", size=9)
WRAP        = Alignment(wrap_text=True, vertical="top")
CENTER      = Alignment(horizontal="center", vertical="top", wrap_text=True)
thin        = Side(style="thin", color="BFBFBF")
BORDER      = Border(left=thin, right=thin, top=thin, bottom=thin)


# ─── DATA EXTRACTION ──────────────────────────────────────────────────────────

def extract_report_kpis(json_path: str, report_label: str) -> list:
    with open(json_path) as f:
        data = json.load(f)

    seen, kpis = set(), []
    for sheet in data.get("sheets", []):
        for table in sheet.get("tables", []):
            for col in table.get("columns", []):
                name    = (col.get("column_name") or "").strip()
                formula = (col.get("formula_pattern") or col.get("formula") or "").strip()
                defn    = (col.get("definition") or "").strip()
                if not name or col.get("type") in ("label", "raw"):
                    continue
                key = (name, formula)
                if key in seen:
                    continue
                seen.add(key)
                kpis.append({
                    "report":     report_label,
                    "col_name":   name,
                    "formula":    formula,
                    "definition": defn,
                    "sheet":      sheet.get("sheet_name", ""),
                    "table":      table.get("table_name", ""),
                })
    print(f"  [{report_label}] Extracted {len(kpis)} unique KPIs")
    return kpis


def extract_ontology_kpis(xlsx_path: str) -> list:
    df = pd.read_excel(xlsx_path, sheet_name="LA_Actuarial_Reserving")
    kpis = []
    for _, row in df.iterrows():
        kpis.append({
            "kpi_name":   str(row.get("KPI / Metric Name") or "").strip(),
            "formula":    str(row.get("Formula") or "").strip(),
            "definition": str(row.get("Definition") or "").strip(),
            "category":   str(row.get("KPI Category") or "").strip(),
            "synonyms":   str(row.get("Alternate Names / Synonyms") or "").strip(),
        })
    print(f"  [Ontology] Extracted {len(kpis)} KPIs")
    return kpis


# ─── LLM ──────────────────────────────────────────────────────────────────────

def build_prompt(r: dict, o: dict) -> str:
    has_formula = bool(r["formula"]) or bool(o["formula"])
    mode = "formula-based" if has_formula else "name/definition-based"
    return f"""You are an insurance KPI mapping expert specializing in actuarial life & annuity reserving.

Compare the following Report KPI with the Ontology KPI.

--- REPORT KPI ---
Name      : {r["col_name"]}
Formula   : {r["formula"] or "(not available)"}
Definition: {r["definition"] or "(not available)"}

--- ONTOLOGY KPI ---
Name      : {o["kpi_name"]}
Formula   : {o["formula"] or "(not available)"}
Definition: {o["definition"] or "(not available)"}
Synonyms  : {o["synonyms"] or "(none)"}

INSTRUCTIONS:
- Comparison mode: {mode}
- Do NOT compare formulas as plain text or string matching.
- Understand the actual business calculation and actuarial metric meaning.
- If formulas are present, compare what each formula COMPUTES (e.g., gross minus ceded = net reserve).
- If formula is missing for either side, compare using KPI name and definition with actuarial domain knowledge.
- These formulas belong to metrics inside real actuarial reserving reports (statutory, GAAP, tax reserves, face amounts, reinsurance, etc.).
- Consider synonyms listed in the ontology KPI.

Respond ONLY in this exact format — no extra text, no markdown:
SCORE: <number between 0.0 and 1.0>
RATIONALE: <1-3 sentences explaining the actuarial similarity or difference>"""


def call_gemini(client, prompt: str, retries: int = 3) -> tuple:
    for attempt in range(retries):
        try:
            resp = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
            text = resp.text.strip()
            lines = {l.split(":")[0].strip(): ":".join(l.split(":")[1:]).strip()
                     for l in text.split("\n") if ":" in l}
            score     = float(lines.get("SCORE", "0.0"))
            rationale = lines.get("RATIONALE", "No rationale provided.")
            return round(min(max(score, 0.0), 1.0), 4), rationale
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
            else:
                return 0.0, f"LLM error: {str(e)}"


# ─── COMPARISON LOOP ──────────────────────────────────────────────────────────

def run_comparisons(report_kpis: list, ontology_kpis: list, client) -> list:
    rows, total, done = [], len(report_kpis) * len(ontology_kpis), 0
    for r in report_kpis:
        for o in ontology_kpis:
            score, rationale = call_gemini(client, build_prompt(r, o))
            rows.append({
                "Report":              r["report"],
                "Column Name":         r["col_name"],
                "Report Formula":      r["formula"],
                "Report Definition":   r["definition"],
                "Ontology KPI":        o["kpi_name"],
                "Ontology Formula":    o["formula"],
                "Ontology Definition": o["definition"],
                "Ontology Category":   o["category"],
                "Similarity Score":    score,
                "Rationale":           rationale,
            })
            done += 1
            if done % 20 == 0 or done == total:
                print(f"  Progress: {done}/{total}")
            time.sleep(0.6)   # ~100 RPM safety margin for flash model
    return rows


# ─── EXCEL BUILDING ───────────────────────────────────────────────────────────

def cl(n): return get_column_letter(n)


def style_header(ws, col_count):
    for c in range(1, col_count + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill, cell.font, cell.alignment, cell.border = HEADER_FILL, HEADER_FONT, CENTER, BORDER
    ws.row_dimensions[1].height = 36


def write_mapping_sheet(wb: Workbook, rows: list, sheet_title: str):
    ws = wb.create_sheet(sheet_title)
    headers = [
        "Report", "Column Name", "Report Formula", "Report Definition",
        "Ontology KPI", "Ontology Formula", "Ontology Definition", "Ontology Category",
        "Similarity Score", "Rationale"
    ]
    widths = [12, 28, 50, 45, 30, 50, 45, 22, 14, 65]
    ws.append(headers)
    style_header(ws, len(headers))
    ws.freeze_panes = "A2"
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[cl(i)].width = w

    df = pd.DataFrame(rows)
    if df.empty:
        return ws

    # Best match index per (report, column)
    df["_key"] = df["Report"] + "||" + df["Column Name"]
    best_flat_indices = set(df.groupby("_key")["Similarity Score"].idxmax().values)

    # Shared ontology KPIs — top match for at least one column in EACH of the two reports
    def top_onto(report):
        sub = df[df["Report"] == report]
        if sub.empty: return set()
        return set(sub.loc[sub.groupby("Column Name")["Similarity Score"].idxmax().values, "Ontology KPI"])

    shared_onto = top_onto("Report A") & top_onto("Report B")

    for flat_idx, row in enumerate(rows):
        row_data = [
            row["Report"], row["Column Name"], row["Report Formula"], row["Report Definition"],
            row["Ontology KPI"], row["Ontology Formula"], row["Ontology Definition"],
            row["Ontology Category"], row["Similarity Score"], row["Rationale"]
        ]
        ws.append(row_data)
        excel_row = flat_idx + 2

        is_best   = flat_idx in best_flat_indices
        is_shared = is_best and row["Ontology KPI"] in shared_onto

        for c in range(1, len(headers) + 1):
            cell = ws.cell(row=excel_row, column=c)
            cell.font, cell.alignment, cell.border = BODY_FONT, WRAP, BORDER
            if is_shared:
                cell.fill = YELLOW_FILL
            elif is_best:
                cell.fill = GREEN_FILL

        score_cell = ws.cell(row=excel_row, column=9)
        score_cell.number_format = "0.00"
        score_cell.alignment = CENTER

    ws.auto_filter.ref = f"A1:{cl(len(headers))}1"
    return ws


def write_methodology_sheet(wb: Workbook):
    ws = wb.create_sheet("Methodology")
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 85

    title_f   = Font(bold=True, name="Arial", size=14, color="1F4E79")
    section_f = Font(bold=True, name="Arial", size=10, color="2E75B6")
    body_al   = Alignment(wrap_text=True, vertical="top")

    def add(label, text, is_title=False, is_section=False):
        ws.append([label, text])
        r = ws.max_row
        ws.cell(r, 1).font = title_f if is_title else (section_f if is_section else BODY_FONT)
        ws.cell(r, 1).alignment = body_al
        ws.cell(r, 2).font = BODY_FONT
        ws.cell(r, 2).alignment = body_al
        ws.row_dimensions[r].height = 60 if (is_section or text and len(text) > 80) else 20
        ws.append([])

    add("ONTOLOGY MAPPING METHODOLOGY — STEP 1", "", is_title=True)
    add("Objective", "Map each KPI column from Report A and Report B to the most semantically "
        "and actuarially similar KPI in the Life & Annuity Actuarial Reserving Ontology. "
        "The goal is business-meaning alignment, not text/string matching.", is_section=True)
    add("Input Files",
        "1. Report A: LNBAR Worksite A Reserve Details (JSON)\n"
        "2. Report B: LNBAR 2024 EB Reserve Details (JSON)\n"
        "3. Ontology: Life & Annuity Actuarial Reserving KPI Ontology (Excel — LA_Actuarial_Reserving sheet, 98 KPIs)",
        is_section=True)
    add("KPI Extraction",
        "KPI columns are extracted from each report JSON by iterating over all sheets and tables. "
        "Columns of type 'label' or 'raw' (e.g., Policy Number, Plan Code) are excluded — "
        "they are dimension fields, not calculated metrics. Each extracted KPI carries: Name, Formula Pattern, and Definition.",
        is_section=True)
    add("LLM Comparison (Gemini)",
        f"Model: {GEMINI_MODEL}. Each report KPI is compared against every ontology KPI. "
        "The LLM is explicitly prompted to interpret formulas as actuarial business calculations — "
        "understanding relationships like Gross minus Ceded = Net, SUM of reinsurance = 3rd party cession, etc.",
        is_section=True)
    add("Matching Logic",
        "PRIMARY: Formula-based — if both report KPI and ontology KPI have a formula, "
        "the LLM compares what the formulas COMPUTE, not their text.\n"
        "FALLBACK: Name/definition-based — if either side lacks a formula, "
        "the LLM uses actuarial knowledge to assess semantic similarity from the KPI name and definition.",
        is_section=True)
    add("Similarity Score", "0.0 = Completely unrelated metrics\n"
        "0.5 = Related concept but different scope or calculation\n"
        "0.8+ = Strongly aligned actuarial metric\n1.0 = Exact or near-exact actuarial equivalent", is_section=True)
    add("GREEN Highlight", "Highest-scoring ontology KPI for that (Report, Column) pair — the best match.")
    add("YELLOW Highlight",
        "The same ontology KPI is the top match for at least one column in BOTH Report A "
        "and Report B — indicating cross-report convergence on the same ontology concept.")
    add("Next Steps",
        "Step 2: For each (Report, Column), retain only the top-scoring row — final 1:1 mapping.\n"
        "Step 3: For each ontology KPI, aggregate which columns from each report map to it "
        "to support cross-report reconciliation and consolidation.")
    return ws


# ─── MAIN ─────────────────────────────────────────────────────────────────────

def main():
    if not GEMINI_API_KEY:
        raise ValueError(
            "GEMINI_API_KEY is not set.\n"
            "Either export it: export GEMINI_API_KEY='your-key'\n"
            "Or paste it directly in the script at line ~20."
        )

    print("\n=== Ontology Matcher — Step 1 ===\n")
    client = genai.Client(api_key=GEMINI_API_KEY)

    print("Extracting KPIs...")
    report_a = extract_report_kpis(os.path.join(INPUT_DIR, "report_a.json"), "Report A")
    report_b = extract_report_kpis(os.path.join(INPUT_DIR, "report_b.json"), "Report B")
    ontology = extract_ontology_kpis(os.path.join(INPUT_DIR, "ontology.xlsx"))

    total = (len(report_a) + len(report_b)) * len(ontology)
    print(f"\nTotal LLM calls: {total}  (~{total * 0.6 / 60:.1f} min at 100 RPM)\n")

    print("--- Report A comparisons ---")
    rows_a = run_comparisons(report_a, ontology, client)

    print("\n--- Report B comparisons ---")
    rows_b = run_comparisons(report_b, ontology, client)

    print("\nBuilding Excel output...")
    wb = Workbook()
    wb.remove(wb.active)
    write_mapping_sheet(wb, rows_a, "Report A Mapping")
    write_mapping_sheet(wb, rows_b, "Report B Mapping")
    write_mapping_sheet(wb, rows_a + rows_b, "Combined Mapping")
    write_methodology_sheet(wb)
    wb.save(OUTPUT_PATH)

    print(f"\n✅ Done — {len(rows_a) + len(rows_b)} total rows")
    print(f"📁 Output: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
