import React, { useEffect } from 'react';
import ArchitectureDiagram from './ArchitectureDiagram';

const FlowAnimationScreen = ({ activeFlows, onComplete }) => {
  useEffect(() => {
    // Wait 2 seconds, then execute onComplete
    const timer = setTimeout(() => {
      onComplete();
    }, 4500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="flow-animation-overlay">
      <div className="flow-animation-content" style={{ transform: 'scale(1.25)', transformOrigin: 'center' }}>
        <h2 className="animation-title">Provisioning Agents...</h2>
        <ArchitectureDiagram activeFlows={activeFlows} />
      </div>
    </div>
  );
};

export default FlowAnimationScreen;
